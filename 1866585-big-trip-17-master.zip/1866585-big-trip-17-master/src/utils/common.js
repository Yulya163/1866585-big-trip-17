export const isEscapePressed = (evt) => evt.key === 'Escape' || evt.key === 'Esc';
